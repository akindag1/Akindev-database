'use strict';
const fs = require('fs');
const path = require('path');
const zlib = require('zlib');
const { pipeline } = require('stream/promises');
const mysqldump = require('mysqldump');
const { sendBackup } = require('./discord');
const { parseConnectionString, redact, isValidWebhook, pruneBackups } = require('./lib');

const resourceName = typeof GetCurrentResourceName === 'function' ? GetCurrentResourceName() : 'Akindev_database';
const root = typeof GetResourcePath === 'function' ? GetResourcePath(resourceName) : __dirname;

const log = {
    ok:   (m) => console.log(`[^2${resourceName}^7] ${m}`),
    warn: (m) => console.log(`[^3${resourceName}^7] ${m}`),
    err:  (m) => console.log(`[^1${resourceName}^7] ${m}`),
};

let config = {};
try {
    config = require('./config.json');
} catch (e) {
    log.err(`config.json okunamadi: ${e.message}`);
}

const getConvar = (name) =>
    typeof GetConvar === 'function' ? GetConvar(name, '') : (process.env[name] || '');

function resolveDb() {
    const fromCfg = config.database_info || {};
    let parsed = null;
    try {
        parsed = parseConnectionString(getConvar('akindev_db_connection') || getConvar('mysql_connection_string'));
    } catch (e) {
        log.warn(`Baglanti metni cozumlenemedi, config.json kullanilacak: ${e.message}`);
    }
    const src = parsed && parsed.database ? parsed : fromCfg;
    return {
        host: src.host || 'localhost',
        port: Number(src.port) || 3306,
        user: src.user || 'root',
        password: src.password || '',
        database: src.database || '',
    };
}

const db = resolveDb();
const discord = config.discord || {};
const webhookUrl = (getConvar('akindev_db_webhook') || discord.webhook || '').trim();
const secrets = [db.password, webhookUrl];

const keepLast = Number.isInteger(config.backup && config.backup.keepLast) ? config.backup.keepLast : 24;
const runOnStart = !!(config.backup && config.backup.runOnStart);
const maxUploadMB = Number(discord.maxUploadMB) > 0 ? Number(discord.maxUploadMB) : 10;

const MIN_MINUTES = 5;
let intervalMinutes = Number(config.interval && config.interval.time);
if (!(intervalMinutes > 0)) intervalMinutes = 60;
if (intervalMinutes < MIN_MINUTES) {
    log.warn(`interval.time ${MIN_MINUTES} dakikadan kisa olamaz, ${MIN_MINUTES} kullaniliyor.`);
    intervalMinutes = MIN_MINUTES;
}

const sqlDir = path.join(root, 'sql');
fs.mkdirSync(sqlDir, { recursive: true });

const formatSize = (bytes) =>
    bytes >= 1024 * 1024 ? `${(bytes / (1024 * 1024)).toFixed(2)} MB` : `${(bytes / 1024).toFixed(1)} KB`;

async function sendToDiscord(filePath, filename, dbName) {
    const bytes = fs.statSync(filePath).size;
    const tooBig = bytes / (1024 * 1024) > maxUploadMB;

    await sendBackup({
        url: webhookUrl,
        username: 'Akindev Database',
        color: discord.color,
        footer: discord.footer,
        fields: [
            { name: 'Veritabani', value: dbName },
            { name: 'Dosya', value: filename },
            { name: 'Boyut', value: formatSize(bytes) },
        ],
        description: tooBig
            ? `Yedek ${maxUploadMB} MB sinirini asti, Discord'a yuklenmedi. Sunucuda sql klasorunde saklaniyor.`
            : undefined,
        filePath: tooBig ? null : filePath,
        filename,
    });

    if (tooBig) log.warn(`Yedek cok buyuk (${formatSize(bytes)}), Discord'a yuklenmedi.`);
    else log.ok(`Yedek Discord'a gonderildi: ${filename} (${formatSize(bytes)})`);
}

async function executeBackup() {
    if (!db.database || !db.database.trim()) {
        log.err('Veritabani adi tanimli degil (config.json veya baglanti metni).');
        return;
    }

    const safeName = db.database.replace(/[^a-zA-Z0-9_-]/g, '_');
    const stamp = new Date().toISOString().replace(/[:.]/g, '-');
    const rawName = `${safeName}-${stamp}.sql`;
    const rawPath = path.join(sqlDir, rawName);
    const filename = `${rawName}.gz`;
    const fullPath = path.join(sqlDir, filename);

    const removeQuietly = (p) => { try { fs.unlinkSync(p); } catch (_) { /* dosya yoksa sorun degil */ } };

    try {
        await mysqldump({
            connection: {
                host: db.host,
                port: db.port,
                user: db.user,
                password: db.password,
                database: db.database,
            },
            dumpToFile: rawPath,
        });

        await pipeline(
            fs.createReadStream(rawPath),
            zlib.createGzip({ level: 9 }),
            fs.createWriteStream(fullPath),
        );
    } catch (err) {
        removeQuietly(fullPath);
        log.err(`Yedekleme hatasi: ${redact(err.message, secrets)}`);
        return;
    } finally {
        removeQuietly(rawPath);
    }

    if (!fs.existsSync(fullPath)) return;
    log.ok(`Yedek alindi: ${filename} (${formatSize(fs.statSync(fullPath).size)})`);

    if (discord.savetodiscord) {
        if (isValidWebhook(webhookUrl)) {
            try {
                await sendToDiscord(fullPath, filename, db.database);
            } catch (err) {
                log.warn(`Discord gonderim hatasi: ${redact(err.message, secrets)}`);
            }
        } else {
            log.warn('Discord webhook tanimsiz veya gecersiz. server.cfg icine: set akindev_db_webhook "https://discord.com/api/webhooks/..."');
        }
    }

    try {
        const removed = pruneBackups(sqlDir, safeName, keepLast);
        if (removed.length) log.ok(`${removed.length} eski yedek silindi (son ${keepLast} tutuluyor).`);
    } catch (err) {
        log.warn(`Eski yedek temizligi basarisiz: ${err.message}`);
    }
}

async function loop() {
    try {
        await executeBackup();
    } catch (err) {
        log.err(`Beklenmeyen hata: ${redact(err && err.message, secrets)}`);
    }
    setTimeout(loop, intervalMinutes * 60 * 1000);
}

log.ok(`Yedekleme sistemi basladi. Aralik: ${intervalMinutes} dk, saklanan yedek: ${keepLast}.`);
if (!db.password && db.user === 'root') {
    log.warn('Veritabani "root" kullanicisi ve bos sifre ile kullaniliyor. Ayri bir yedek kullanicisi olusturmaniz onerilir (README.md).');
}
if (runOnStart) loop();
else setTimeout(loop, intervalMinutes * 60 * 1000);
