fx_version 'cerulean'
game       'gta5'
node_version '22'

name        'Akindev-database'
author      'Akindev'
description 'Akindev Database Backup System'
version     '1.1.0'

server_script 'index.js'
