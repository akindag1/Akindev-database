'use strict';
const fs = require('fs');
const path = require('path');

// "mysql://user:pass@host:3306/db" veya "user=root;password=x;host=localhost;port=3306;database=db"
function parseConnectionString(str) {
    str = String(str || '').trim();
    if (!str) return null;

    if (/^mysql:\/\//i.test(str)) {
        const u = new URL(str);
        return {
            host: u.hostname || 'localhost',
            port: Number(u.port) || 3306,
            user: decodeURIComponent(u.username || ''),
            password: decodeURIComponent(u.password || ''),
            database: decodeURIComponent((u.pathname || '').replace(/^\//, '')),
        };
    }

    const kv = {};
    for (const part of str.split(';')) {
        const i = part.indexOf('=');
        if (i < 1) continue;
        kv[part.slice(0, i).trim().toLowerCase()] = part.slice(i + 1).trim();
    }
    return {
        host: kv.host || kv.server || 'localhost',
        port: Number(kv.port) || 3306,
        user: kv.user || kv.uid || kv.userid || '',
        password: kv.password || kv.pwd || '',
        database: kv.database || kv.db || '',
    };
}

function redact(text, secrets) {
    let out = String(text);
    for (const s of secrets || []) {
        const v = s == null ? '' : String(s);
        if (v.length >= 4) out = out.split(v).join('***');
    }
    return out;
}

function isValidWebhook(url) {
    return typeof url === 'string' &&
        /^https:\/\/(discord|discordapp)\.com\/api\/webhooks\/\d+\/[\w-]+$/.test(url.trim());
}

function escapeRegExp(s) {
    return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

function pruneBackups(dir, prefix, keep) {
    if (!Number.isInteger(keep) || keep < 1) return [];
    const re = new RegExp('^' + escapeRegExp(prefix) + '-\\d{4}-\\d{2}-\\d{2}T[\\w-]+\\.sql(\\.gz)?$');
    const files = fs.readdirSync(dir).filter(f => re.test(f)).sort();
    const old = files.slice(0, Math.max(0, files.length - keep));
    for (const f of old) {
        try { fs.unlinkSync(path.join(dir, f)); } catch (_) { /* yoksay */ }
    }
    return old;
}

module.exports = { parseConnectionString, redact, isValidWebhook, pruneBackups };
