'use strict';
const fs = require('fs');

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function colorToInt(c) {
    const m = /^#?([0-9a-f]{6})$/i.exec(String(c || ''));
    return m ? parseInt(m[1], 16) : 0x0099ff;
}

const HTTP_HINTS = {
    401: 'webhook gecersiz',
    404: 'webhook silinmis veya adres yanlis',
    413: 'dosya Discord limitini asiyor',
};

async function postWebhook(url, makeForm, { retries = 2, timeoutMs = 60000 } = {}) {
    for (let attempt = 0; ; attempt++) {
        const res = await fetch(url, {
            method: 'POST',
            body: makeForm(),
            signal: AbortSignal.timeout(timeoutMs),
        });
        if (res.ok) return;

        if (res.status === 429 && attempt < retries) {
            let wait = 5;
            try {
                const j = await res.json();
                if (j && j.retry_after) wait = Number(j.retry_after);
            } catch (_) { /* varsayilan sure */ }
            await sleep(Math.min(Math.max(wait, 1), 30) * 1000);
            continue;
        }

        const hint = HTTP_HINTS[res.status];
        throw new Error(`Discord HTTP ${res.status}${hint ? ` (${hint})` : ''}`);
    }
}

async function sendBackup({ url, username, color, footer, fields, description, filePath, filename }) {
    const embed = {
        author: { name: 'Akindev Database Backup' },
        timestamp: new Date().toISOString(),
        color: colorToInt(color),
        fields: fields.map((f) => ({ name: f.name, value: String(f.value) || '-', inline: true })),
        footer: { text: footer || 'Akindev Database Backup' },
    };
    if (description) embed.description = description;

    const buf = filePath ? await fs.promises.readFile(filePath) : null;

    const makeForm = () => {
        const form = new FormData();
        const payload = { username, embeds: [embed] };
        if (buf) payload.attachments = [{ id: 0, filename }];
        form.append('payload_json', JSON.stringify(payload));
        if (buf) form.append('files[0]', new Blob([buf], { type: 'application/gzip' }), filename);
        return form;
    };

    await postWebhook(url, makeForm);
}

module.exports = { sendBackup, colorToInt };
